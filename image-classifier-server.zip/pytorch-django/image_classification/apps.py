from django.apps import AppConfig


class ImageClassificationConfig(AppConfig):
    name = 'image_classification'
